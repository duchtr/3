package uet.oop.bomberman.entities;

import javafx.scene.image.Image;
import uet.oop.bomberman.BombermanGame;
import uet.oop.bomberman.graphics.Sprite;

public class Oneal extends Entity {
    public long timeDied = 1;
    public boolean died = false;
    long startTime = BombermanGame.time;
    long lastTime = 0;
    long time = 0;

    public Oneal(int x, int y, Image img) {
        super(x, y, img);
    }

    @Override
    public void update() {
        if (timeDied<1) died = true;
        if ( (BombermanGame.time - startTime)/100> lastTime) {
            lastTime = (BombermanGame.time - startTime)/100;
        }
        if (this.intersects(BombermanGame.bomberman)) BombermanGame.bomberman.bomberDied();
    }

    public void onealDied(){
        if ( (BombermanGame.time - startTime)/1000 > time) {
            if (timeDied>=0) timeDied--;
            time = (BombermanGame.time - startTime)/1000;
        }
        this.img = Sprite.oneal_dead.getFxImage();
    }
}
